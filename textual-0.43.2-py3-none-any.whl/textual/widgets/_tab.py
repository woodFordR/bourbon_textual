from ._tabs import Tab

__all__ = ["Tab"]
